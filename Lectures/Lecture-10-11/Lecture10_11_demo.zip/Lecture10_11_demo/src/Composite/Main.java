package Composite;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.ArrayList;

public class Main extends Application {
    ArrayList<Graphic> graphics = new ArrayList<>();

    public void initializeGraphics() {
        Graphic n = new Line("neck", 220, 80, 220, 100);
        graphics.add(n);

        Graphic h1 = new Line("hand1", 110, 150, 185, 120);
        Graphic h2 = new Line("hand2", 255, 120, 325, 150);
        graphics.add(h1);
        graphics.add(h2);

        Graphic f1 = new Line("foot1", 190, 170, 115, 250);
        Graphic f2 = new Line("foot2", 250, 170, 325, 250);
        graphics.add(f1);
        graphics.add(f2);

        Graphic he = new Circle("head", 200, 40, 80);
        Graphic b = new Circle("belly", 180, 100, 160);
        graphics.add(he);
        graphics.add(b);

        Picture lines = new Picture("lines");
        lines.add(n);
        lines.add(h1);
        lines.add(h2);
        lines.add(f1);
        lines.add(f2);
        graphics.add(lines);

        Picture circles = new Picture("circles");
        circles.add(he);
        circles.add(b);
        graphics.add(circles);

        Picture p = new Picture("stick figure");
//        p.add(n);
//        p.add(h1);
//        p.add(h2);
//        p.add(f1);
//        p.add(f2);
//        p.add(he);
//        p.add(b);
        p.add(lines);
        p.add(circles);
        graphics.add(p);
    }

    void populateList(ListView list) {
        for (Graphic g : graphics)
            list.getItems().add(g.getName());
    }

    @Override
    public void start(Stage stage) throws Exception {
        initializeGraphics();

        stage.setTitle("Drawing a stick figure");
        HBox root = new HBox();

        ListView<String> listView = new ListView();
        populateList(listView);

        Canvas canvas = new Canvas(600, 250);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        listView.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
                int index = listView.getSelectionModel().getSelectedIndex();
                Graphic g = graphics.get(index);
                g.draw(gc);
            }
        });

        root.getChildren().add(listView);
        root.getChildren().add(canvas);
        stage.setScene(new Scene(root));

        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
