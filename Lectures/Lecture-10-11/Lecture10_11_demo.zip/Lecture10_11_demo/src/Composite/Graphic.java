package Composite;

import javafx.scene.canvas.GraphicsContext;

import java.util.ArrayList;

public abstract class Graphic {
    protected String name;

    public Graphic(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract void draw(GraphicsContext gc);
}

class Line extends Graphic {
    int x1, y1, x2, y2;

    public Line(String name, int x1, int y1, int x2, int y2) {
        super(name);
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.strokeLine(x1, y1, x2, y2);
    }
}

class Circle extends Graphic {
    int x, y, radius;

    public Circle(String name, int x, int y, int radius) {
        super(name);
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.strokeOval(x, y, radius/2, radius/2);
    }
}

class Picture extends Graphic {
    private ArrayList<Graphic> elements = new ArrayList<>();

    public Picture(String name) {
        super(name);
    }

    @Override
    public void draw(GraphicsContext gc) {
        for (Graphic g: elements)
            g.draw(gc);
    }

    public void add(Graphic g) {
        elements.add(g);
    }
}