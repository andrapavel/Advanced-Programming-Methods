package AbstractFactory;

public class MACCheckBox implements MyCheckBox {

    @Override
    public void render() {
        System.out.println("MAC checkbox");
    }
}