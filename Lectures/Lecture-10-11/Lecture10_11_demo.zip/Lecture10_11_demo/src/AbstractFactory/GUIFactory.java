package AbstractFactory;

public interface GUIFactory {
    MyButton createButton();
    MyCheckBox createCheckBox();
}

class WindowsFactory implements GUIFactory {

    @Override
    public MyButton createButton() {
        return new WindowsButton();
    }

    @Override
    public MyCheckBox createCheckBox() {
        return new WindowsCheckBox();
    }
}

class MACFactory implements GUIFactory {

    @Override
    public MyButton createButton() {
        return new MACButton();
    }

    @Override
    public MyCheckBox createCheckBox() {
        return new MACCheckBox();
    }
}