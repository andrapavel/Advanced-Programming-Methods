package AbstractFactory;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public class MyApplication {
    private MyButton button;
    private MyCheckBox checkBox;

    void createGUI(GUIFactory factory)
    {
        button = factory.createButton();
        checkBox = factory.createCheckBox();
    }

    void render()
    {
        button.render();
        checkBox.render();
    }
}
