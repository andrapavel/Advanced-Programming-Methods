package AbstractFactory;

import javax.swing.*;

public class WindowsButton implements MyButton {
    JFrame frame;
    JPanel panel;
    JButton button;

    @Override
    public void render() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        panel = new JPanel();
        button = new JButton("Windows button");
        panel.add(button);
        frame.getContentPane().add(panel);
        frame.setSize(200, 200);
        frame.setVisible(true);
    }
}
