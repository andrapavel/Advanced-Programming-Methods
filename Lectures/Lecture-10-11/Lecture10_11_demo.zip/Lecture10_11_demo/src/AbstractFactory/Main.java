package AbstractFactory;

public class Main {
    public static void main(String[] args) {
        MyApplication app;
        GUIFactory guiFactory;

        if (System.getProperty("os.name").equals("Windows 10"))
            guiFactory = new WindowsFactory();
        else
            guiFactory = new MACFactory();

        app = new MyApplication();
        app.createGUI(guiFactory);
        app.render();
    }
}