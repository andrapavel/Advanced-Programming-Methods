package AbstractFactory;

public class MACButton implements MyButton
{
    @Override
    public void render() {
        System.out.println("MAC button");
    }
}
