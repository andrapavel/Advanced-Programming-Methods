package AbstractFactory;

import javax.swing.*;

public class WindowsCheckBox implements MyCheckBox {
    private JCheckBox checkBox;
    JFrame frame;
    JPanel panel;

    @Override
    public void render() {
        frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        panel = new JPanel();
        checkBox = new JCheckBox("Windows check box");
        panel.add(checkBox);
        frame.getContentPane().add(panel);
        frame.setSize(200, 200);
        frame.setVisible(true);
    }
}

