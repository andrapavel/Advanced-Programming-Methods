package Observer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;

public class Controller implements Observer {

    private Service serv;

    public Controller(Service serv) {
        this.serv = serv;
    }

    @FXML
    private ListView<Product> productsListView;

    @FXML
    private Button addButton;

    @FXML
    private Label totalProductsLabel;

    @FXML
    private Label transportLabel;

    @FXML
    private Label totalLabel;

    public void initialize()
    {
        this.populateList();
        this.updateLabels();
    }

    private void populateList()
    {
        productsListView.getItems().clear();
        for (Product p: serv.getAll())
            productsListView.getItems().add(p);
    }

    public void updateLabels()
    {
        int productsSum = serv.getProductsSum();
        totalProductsLabel.setText(String.valueOf(productsSum));
        if (productsSum < 250)
        {
            transportLabel.setText("17");
            totalLabel.setText(String.valueOf(17 + productsSum));
        }
        else
        {
            transportLabel.setText("0");
            totalLabel.setText(String.valueOf(productsSum));
        }
    }

    @FXML
    void onAddButtonHandler(ActionEvent event) {
        serv.addProduct("honey", 18);
        this.populateList();
        this.updateLabels();
    }

    @Override
    public void update() {
        this.populateList();
        this.updateLabels();
    }
}