package Observer;

import java.util.ArrayList;

public class Service extends Subject{
    private ArrayList<Product> products = new ArrayList<>();

    public void addProduct(String name, int price)
    {
        Product p = new Product(name, price);
        products.add(p);

        notifyAllObservers();
    }

    public ArrayList<Product> getAll() {
        return products;
    }

    public int getProductsSum()
    {
        return products.stream().map(p -> p.getPrice()).reduce(0, Integer::sum);
    }
}
