package Observer;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ObserverMainApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    public Scene createScene(Service serv) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(ObserverMainApp.class.getResource("/Observer/ProductsWindow.fxml"));
        Controller controller = new Controller(serv);
        serv.addObserver(controller);
        fxmlLoader.setController(controller);
        Parent root = (Parent)fxmlLoader.load();
        Scene scene = new Scene(root, 320, 240);

        return scene;
    }

    @Override
    public void start(Stage stage) throws IOException {

        Service serv = new Service();
        serv.addProduct("milk", 11);
        serv.addProduct("bread", 8);
        serv.addProduct("butter", 19);

        // stage 1
        Scene scene1 = createScene(serv);
        stage.setTitle("Department store application");
        stage.setScene(scene1);
        stage.show();

        // stage 2
        Stage stage2 = new Stage();
        Scene scene2 = createScene(serv);
        stage2.setTitle("Department store application");
        stage2.setScene(scene2);
        stage2.show();


        // stage 3
        Stage stage3 = new Stage();
        Scene scene3 = createScene(serv);
        stage3.setTitle("Department store application");
        stage3.setScene(scene3);
        stage3.show();
    }
}
