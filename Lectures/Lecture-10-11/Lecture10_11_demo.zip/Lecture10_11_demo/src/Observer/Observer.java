package Observer;

import java.util.ArrayList;

interface Observer {
    void update();
}

class Subject
{
    private ArrayList<Observer> observers = new ArrayList<>();

    public void addObserver(Observer obs)
    {
        observers.add(obs);
    }

    public void notifyAllObservers()
    {
        for (Observer o: observers)
            o.update();
    }
}
