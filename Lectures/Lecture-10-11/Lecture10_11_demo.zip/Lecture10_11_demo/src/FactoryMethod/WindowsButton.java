package FactoryMethod;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class WindowsButton extends Application implements MyButton {
    Button button;

    @Override
    public void render() {
        String[] args = new String[2];
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        button = new Button("Windows button");

        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("Windows button was pressed.");
                alert.showAndWait();
            }
        });

        stage.setScene(new Scene(button));
        stage.show();
    }
}
