package FactoryMethod;

public class HTMLDialog extends Dialog {

    @Override
    public MyButton createButton() {
        return new HtmlButton();
    }
}
