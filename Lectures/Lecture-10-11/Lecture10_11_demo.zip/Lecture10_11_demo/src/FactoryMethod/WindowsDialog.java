package FactoryMethod;

public class WindowsDialog extends Dialog {
    @Override
    public MyButton createButton() {
        return new WindowsButton();
    }
}
