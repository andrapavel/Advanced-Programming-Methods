package FactoryMethod;

public abstract class Dialog {
    public abstract MyButton createButton();

    public void renderDialog()
    {
        // create all other elements
        MyButton button = this.createButton();
        button.render();
    }
}