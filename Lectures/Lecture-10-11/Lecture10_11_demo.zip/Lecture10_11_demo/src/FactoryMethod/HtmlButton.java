package FactoryMethod;

public class HtmlButton implements MyButton {
    public void render() {
        System.out.println("<button>HTML Button</button>");
    }
}
