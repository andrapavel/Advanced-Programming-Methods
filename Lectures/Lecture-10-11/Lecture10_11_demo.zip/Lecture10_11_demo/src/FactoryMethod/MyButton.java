package FactoryMethod;

public interface MyButton {
    void render();
}
