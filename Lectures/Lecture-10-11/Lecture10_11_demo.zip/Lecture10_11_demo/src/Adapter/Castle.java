package Adapter;

public class Castle {
    private String description;
    private String location;
    private double price;

    public Castle(String description, String location, double price) {
        this.description = description;
        this.location = location;
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }

    public double getPrice() {
        return price;
    }
}
