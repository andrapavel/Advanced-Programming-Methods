package Adapter;

public class AdapterClass extends GoCardlessUK implements PaymentService{
    private double euroToPoundsRate;

    public AdapterClass(double euroToPoundsRate) {
        this.euroToPoundsRate = euroToPoundsRate;
    }

    @Override
    public void pay(double sum) {
        double sumPounds = euroToPoundsRate * sum;
        this.sendPayment(sumPounds);
        System.out.println("Paid " + sumPounds + " pounds via GoCardlessUK.");
    }
}
