package Adapter;

public interface PaymentService {
    void pay(double sum);
}

class PayPal implements PaymentService {

    @Override
    public void pay(double sum) {
        System.out.println("Paid " + sum + " million euro using PayPal.");
    }
}

class Skrill implements PaymentService {

    @Override
    public void pay(double sum) {
        System.out.println("Paid " + sum + " million euro using Skrill.");
    }
}

class GoCardlessUK
{
    void sendPayment(double sumInPounds)
    {
        System.out.println("Sending payment through GoCardlessUK.");
    }
};