package Adapter;

public class Main {
    public static void main(String[] args) {

        Controller ctrl = new Controller();
        ctrl.addCastle("Highclere Castle", "England", 4);
        ctrl.addCastle("Chambord Castle", "France", 3.2);
        ctrl.addCastle("Windsor Castle", "England", 5.8);
        ctrl.addCastle("Scaliger Castle", "Italy", 2.9);

        // buy Highclere Castle and pay via PayPal
        ctrl.setCurrent(0);
        ctrl.buy(new PayPal());

        // buy Chambord Castle and pay via Skrill
        ctrl.setCurrent(1);
        ctrl.buy(new Skrill());

        ctrl.setCurrent(2);
        // buy Windsor Castle and pay via GoCardlessUK
        // use class adapter
        ctrl.buy(new AdapterClass(0.78));

        // use object adapter
		GoCardlessUK goCardlessService = new GoCardlessUK();
		ctrl.buy(new AdapterObject(0.78, goCardlessService));
    }
}
