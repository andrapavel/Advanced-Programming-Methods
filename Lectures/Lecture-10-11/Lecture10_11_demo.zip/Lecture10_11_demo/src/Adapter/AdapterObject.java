package Adapter;

public class AdapterObject implements PaymentService{
    private double euroToPoundsRate;
    private GoCardlessUK goCardlessService;

    public AdapterObject(double euroToPoundsRate, GoCardlessUK goCardlessService) {
        this.euroToPoundsRate = euroToPoundsRate;
        this.goCardlessService = goCardlessService;
    }

    @Override
    public void pay(double sum) {
        double sumPounds = euroToPoundsRate * sum;
        goCardlessService.sendPayment(sumPounds);
        System.out.println("Paid " + sumPounds + " pounds via GoCardlessUK.");
    }
}
