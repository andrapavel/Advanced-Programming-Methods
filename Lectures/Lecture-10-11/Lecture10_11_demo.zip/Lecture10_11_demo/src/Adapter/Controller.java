package Adapter;

import java.util.ArrayList;

public class Controller {
    private ArrayList<Castle> castles = new ArrayList<>();

    public ArrayList<Castle> getCastles() {
        return castles;
    }

    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) {
        this.current = current;
    }

    private int current;

    void addCastle(String description, String location, double price)
    {
        Castle c = new Castle(description, location, price);
        castles.add(c);
    }

    void buy(PaymentService service)
    {
        service.pay(castles.get(current).getPrice());
    }
}
