module Observer {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires java.desktop;

    opens Observer to javafx.fxml;
    exports Observer;
    exports FactoryMethod;
    exports AbstractFactory;
    exports Composite;
}