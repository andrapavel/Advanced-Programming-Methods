package repository;

import domain.Doctor;

import java.util.ArrayList;

public class Repository {
    private ArrayList<Doctor> doctors = new ArrayList<>();

    public void addDoctor(Doctor d)
    {
        doctors.add(d);
    }

    public ArrayList<Doctor> getAll()
    {
        return this.doctors;
    }
}
