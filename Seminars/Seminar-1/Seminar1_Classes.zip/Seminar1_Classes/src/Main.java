import domain.Doctor;
import repository.Repository;
import service.Service;
import ui.UI;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Repository repo = new Repository();
        Service serv = new Service(repo);
        UI ui = new UI(serv);
        serv.addDoctor("John Smith", "cardiology", "Cluj", 9.7);
        serv.addDoctor("Eve Smith", "gastro", "Brasov", 9.8);

        ui.run();
    }
}