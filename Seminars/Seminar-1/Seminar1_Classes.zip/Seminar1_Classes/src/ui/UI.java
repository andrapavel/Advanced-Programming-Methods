package ui;
import domain.Doctor;
import service.Service;
import java.util.ArrayList;
import java.util.Scanner;

public class UI {
    private Service serv;

    public UI(Service serv)
    {
        this.serv = serv;
    }

    public void listDoctors(){
        ArrayList<Doctor> doctors = this.serv.getAll();
        for (Doctor d: doctors)
            System.out.println(d);
    }

    public void printMenu()
    {
        System.out.println("1 - List all doctors");
        System.out.println("0 - Exit");
    }

    public void run()
    {
        while (true)
        {
            printMenu();
            System.out.print("Please input your option: ");
            Scanner scan = new Scanner(System.in);
            int command = scan.nextInt();
            switch (command)
            {
                case 0:
                    return;
                case 1:
                    listDoctors();
            }
        }
    }
}