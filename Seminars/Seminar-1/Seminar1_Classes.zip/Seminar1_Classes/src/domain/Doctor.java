package domain;

import java.util.Objects;

public class Doctor {
    private String name, specialty, location;
    private double grade;

    public Doctor(String name, String specialty, String location, double grade)
    {
        this.name = name;
        this.specialty = specialty;
        this.location = location;
        this.grade = grade;
    }

    String getName()
    {
        return this.name;
    }

//    public String toString()
//    {
//        return this.name + " " + specialty + " " + location + " " + grade;
//    }


    @Override
    public String toString() {
        return "Doctor{" +
                "name='" + name + '\'' +
                ", specialty='" + specialty + '\'' +
                ", location='" + location + '\'' +
                ", grade=" + grade +
                '}';
    }

    public boolean equals(Object o)
    {
        if (!(o instanceof Doctor))
            return false;
        Doctor d = (Doctor)o;
        if (d.name.equals(this.name) && d.specialty.equals(this.specialty) &&
        d.location.equals(this.location) && d.grade == this.grade)
            return true;
        return false;
    }

}

